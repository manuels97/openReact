import React from 'react';
import Loginformik from '../../components/pure/forms/log';



const Loginpage = () => {
    return (
        <div>
            <h1>Login Page</h1>
            <Loginformik></Loginformik>
        </div>
    );
}

export default Loginpage;
