import React from 'react';
import TaskListComponent from '../../components/containers/task_list';

const Taskspage = () => {
    return (
        <div>
            <TaskListComponent></TaskListComponent>
        </div>
    );
}

export default Taskspage;
