import React from 'react';
import { useNavigate, useLocation } from 'react-router';


const Homepage = () => {
    const location = useLocation();
    const Navigate = useNavigate();

    console.log('We are in Route:', location.pathname); // '/about | /faqs'

    const navigate = (path) => {
        Navigate.push(path);
    }

    const navigateProps = (path) => {
        Navigate.push({
            pathname: path,
            search: '?online=true', // Query Params
            state: {
                online: true
            }
        });
    }

    return (
        <div>
            <h1>Home Page</h1>
            <button onClick={() => navigateProps('/online-state')}>
                Go To Page with State / Query Params
            </button>
            <button onClick={() => navigate('/profile')}>
                Go To Profile
            </button>
        </div>
    );
}

export default Homepage;
